<!DOCTYPE html>
<html>
<head>
    <title>Credit Card Payment Form</title>
</head>
<body>

<h2>Enter Credit Card Details</h2>

<!-- credit_card_form.php -->
<div class="credit-card-form">
    <div class="inputBox">
        <span>Card Number</span>
        <input type="text" name="card_number" placeholder="Enter your card number" maxlength="16"required>
    </div>
    <div class="inputBox">
        <span>Expiry Date</span>
        <input type="text" name="expiry_date" placeholder="MM/YYYY" maxlength="7"required>
    </div>
    <div class="inputBox">
        <span>CVV</span>
        <input type="text" name="cvv" placeholder="Enter CVV" maxlength="3"required>
    </div>
</div>


</body>
</html>
 