<?php
$con = new mysqli('localhost','root','','dfms');

if(!$con)
{
die(mysqli_error($con));
}
 
?>