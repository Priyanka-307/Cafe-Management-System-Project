<?php

session_start();
session_destroy();
header('location:adn_login2.php');
?>